let todoItemsContainer = document.getElementById("todoItemsContainer");
let userinputElement = document.getElementById("todoUserInput");
let addtotobutton = document.getElementById("Addtodoinput");
let todoList = [{
        text: "Learn HTML",
        uniqueno: 1,
    },
    {
        text: "Learn CSS",
        uniqueno: 2,
    },
    {
        text: "Learn JavaScript",
        uniqueno: 3,
    }
];

function onTodoStatuschange(checkboxId, label_id) {
    let CheckboElement = document.getElementById(checkboxId);
    let LableEment = document.getElementById(label_id);
    if (CheckboElement.checked === true) {
        LableEment.classList.add("is_checked");
    } else {
        LableEment.classList.remove("is_checked")
    }
}


function todeleteEment(todoid) {
    let TodolistElement = document.getElementById(todoid);
    todoItemsContainer.removeChild(TodolistElement);
}


function createAndAppendTodo(todo) {
    let todoElement = document.createElement("li");
    todoElement.classList.add("todo-item-container", "d-flex", "flex-row");
    todoItemsContainer.appendChild(todoElement);
    let todoid = todoList + 1;
    todoElement.id = todoid;

    let inputElement = document.createElement("input");
    inputElement.type = "checkbox";
    let checkboxId = "checkboxInput" + todo.uniqueno;
    inputElement.id = checkboxId;
    inputElement.classList.add("checkbox-input");
    todoElement.appendChild(inputElement);

    let labelContainer = document.createElement("div");
    labelContainer.classList.add("label-container", "d-flex", "flex-row");
    todoElement.appendChild(labelContainer);

    let labelElement = document.createElement("label");
    labelElement.setAttribute("for", checkboxId);
    labelElement.classList.add("checkbox-label");
    labelElement.textContent = todo.text;
    labelContainer.appendChild(labelElement);
    let label_id = "lable" + todo.uniqueno;
    labelElement.id = label_id;

    inputElement.onclick = function() {
        onTodoStatuschange(checkboxId, label_id);
    }

    let deleteIconContainer = document.createElement("div");
    deleteIconContainer.classList.add("delete-icon-container");
    labelContainer.appendChild(deleteIconContainer);

    let deleteIcon = document.createElement("i");
    deleteIcon.classList.add("far", "fa-trash-alt", "delete-icon");
    deleteIcon.onclick = function() {
        todeleteEment(todoid);
    };
    deleteIconContainer.appendChild(deleteIcon);
}

function addElement() {
    let todoCount = todoList.length;
    todoCount = todoCount + 1;
    let inputValue = userinputElement.value;
    if (inputValue === "") {
        alert("Enter Valid Input");
        return;
    }
    let newtodo = {
        text: inputValue,
        uniqueno: todoCount,
    };
    createAndAppendTodo(newtodo);
    userinputElement.value = "";

}
addtotobutton.onclick = function() {
    addElement();
}

for (let todo of todoList) {
    createAndAppendTodo(todo);
}