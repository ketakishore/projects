// Example Valid URLs: https://learning.ccbp.in/, https://www.google.com/
let bookmarkForm_Element = document.getElementById("bookmarkForm");
let siteNameInput_Element = document.getElementById("siteNameInput");
let siteUrlInput_Element = document.getElementById("siteUrlInput");
let Submit_btn_Element = document.getElementById("submitBtn");
let siteNameErrMsg_Element = document.getElementById("siteNameErrMsg");
let siteUrlErrMsg_Element = document.getElementById("siteUrlErrMsg");
let bookmarksList_Element = document.getElementById("bookmarksList");
let unorder_container = document.getElementById("unorder");
let Site_Name = document.createElement("a");
let Site_Url = document.createElement("a");
let Site_Name_value = null;
let Site_Url_value = null;
let bookmarksList = [];

function Validate_Name(event) {
    if (siteNameInput_Element.value === "") {
        siteNameErrMsg_Element.textContent = "Requried*";
    } else {
        siteNameErrMsg_Element.textContent = "";
    }

}

function Validate_URL(event) {
    if (siteUrlInput_Element.value === "") {
        siteUrlErrMsg_Element.textContent = "Requried*";
    } else {
        siteUrlErrMsg_Element.textContent = "";
    }
}
siteNameInput_Element.addEventListener("change", function(event) {
    Site_Name_value = event.target.value;
    console.log(Site_Name_value);
    if (siteNameInput_Element.value === "") {
        siteNameErrMsg_Element.textContent = "Requried*";
    } else {
        siteNameErrMsg_Element.textContent = "";
    }

});
siteUrlInput_Element.addEventListener("change", function(event) {
    Site_Url_value = event.target.value;
    console.log(Site_Url_value);
    if (event.target.value === "") {
        siteUrlErrMsg_Element.textContent = "Requried*";
    } else {
        siteUrlErrMsg_Element.textContent = "";
    }

})
Submit_btn_Element.addEventListener("click", function(event) {
    Site_Name.textContent = "";
    Site_Url.textContent = "";
    if (Site_Name_value !== "" && Site_Url_value !== "") {

        let name_list = document.createElement("li");
        bookmarksList_Element.appendChild(name_list);
        unorder_container.classList.remove("d-none");
        Site_Name.textContent = siteNameInput_Element.value;
        name_list.appendChild(Site_Name);
        let breakElement = document.createElement("br");
        name_list.appendChild(breakElement);
        let Url_list = document.createElement("li");
        bookmarksList_Element.appendChild(Url_list);
        Site_Url.textContent = siteUrlInput_Element.value;
        Site_Url.href = siteUrlInput_Element.value;
        Site_Url.target = "_blank";
        Url_list.appendChild(Site_Url);
        bookmarksList.push(Site_Name);
        bookmarksList.push(Site_Url);
    } else {
        siteNameErrMsg_Element.textContent = "Requried*";
        siteUrlErrMsg_Element.textContent = "Requried*";
    }


})




bookmarkForm_Element.addEventListener("submit", function(event) {
    event.preventDefault();
    Validate_Name(event);
    Validate_URL(event);
})