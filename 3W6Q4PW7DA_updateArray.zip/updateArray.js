let arr = [1, 7, 3, 1, 0, 20, 77];
let updated_array = document.getElementById("updatedArray");
let stringify = JSON.stringify(arr);
updated_array.textContent = stringify;
let spliceButton = document.getElementById("spliceBtn");

function UpdatedArray() {
    let startIndex = document.getElementById("startIndexInput").value;
    let DeleteCount = document.getElementById("deleteCountInput").value;
    let Item_to_Add = document.getElementById("itemToAddInput").value;
    arr.splice(startIndex, DeleteCount, Item_to_Add);
    stringify = JSON.stringify(arr);
    updated_array.textContent = stringify;

    document.getElementById("startIndexInput").value = "";
    document.getElementById("deleteCountInput").value = "";
    document.getElementById("itemToAddInput").value = "";

}



spliceButton.onclick = function() {
    UpdatedArray();
}