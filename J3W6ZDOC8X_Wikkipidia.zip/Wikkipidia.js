let search_input_Element = document.getElementById("searchInput");
let search_Results_container = document.getElementById("searchResults");
let spinner_Element = document.getElementById("spinner");


function create_Append_search_results(result) {
    let {
        title,
        link,
        description
    } = result;
    console.log(title);
    console.log(link);
    console.log(description);
    // create Div container for results Items
    let result_item_container = document.createElement("div");
    result_item_container.classList.add("result-item");
    search_Results_container.appendChild(result_item_container);

    // Create Anchar Element for title 
    let result_Title_Element = document.createElement("a");
    result_Title_Element.classList.add("result-title");
    result_Title_Element.textContent = title;
    result_Title_Element.href = link;
    result_Title_Element.target = "_blank";
    result_item_container.appendChild(result_Title_Element);

    //Creating title break Element 
    let Title_break_Element = document.createElement("br");
    result_item_container.appendChild(Title_break_Element);

    // Creating Url with Anchar Element
    let Url_Element = document.createElement("a");
    Url_Element.classList.add("result-url");
    Url_Element.href = link;
    Url_Element.textContent = link;
    Url_Element.target = "_blank";
    result_item_container.appendChild(Url_Element);

    // Creating line break Element 
    let Line_break_Element = document.createElement("br");
    result_item_container.appendChild(Line_break_Element);

    // Creating  description Element 
    let result_description_Element = document.createElement("p");
    result_description_Element.classList.add("link-description");
    result_description_Element.textContent = description;
    result_item_container.appendChild(result_description_Element);

}

function display_response(search_results) {
    spinner_Element.classList.toggle("d-none");
    for (let result of search_results) {
        create_Append_search_results(result);
    }
}


function search_wikipedia(event) {
    if (event.key === "Enter") {
        spinner_Element.classList.toggle("d-none");
        let user_input = search_input_Element.value;
        let url = "https://apis.ccbp.in/wiki-search?search=" + user_input;
        let options = {
            method: "GET",
            header: {
                "content-type": "application/json",
                Accept: "application/json"
            },

        };
        fetch(url, options)
            .then(function(response) {
                return response.json();
            })
            .then(function(jsonData) {
                let {
                    search_results
                } = jsonData;
                display_response(search_results);
            });

    }

}



search_input_Element.addEventListener("keydown", search_wikipedia);