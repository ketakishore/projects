let searchInput_Element = document.getElementById("searchInput");
let resultCountries_Element = document.getElementById("resultCountries");
let spinner_Element = document.getElementById("spinner");
let search_user_input = "";
let countriesList = [];

function create_Append_country_search_results(results) {
    let {
        flag,
        name,
        population
    } = results;
    // create resut_Item Container
    let result_Item_container = document.createElement("div");
    result_Item_container.classList.add("country-card", "d-flex", "flex-row", "ml-5");
    resultCountries_Element.appendChild(result_Item_container);

    // Creating image Element 
    let Flag_image_Element = document.createElement("img");
    Flag_image_Element.src = flag;
    Flag_image_Element.classList.add("country-flag");
    result_Item_container.appendChild(Flag_image_Element);

    //Creating details Container Element 
    let details_container = document.createElement("div");
    details_container.classList.add("d-flex", "flex-column", "ml-auto", "mr-auto", "col-12", "col-md-6");
    result_Item_container.appendChild(details_container);

    // Creatimh Country Name Element 
    let Country_Name_Element = document.createElement("label");
    Country_Name_Element.classList.add("country-name");
    Country_Name_Element.textContent = name;
    details_container.appendChild(Country_Name_Element);

    // Creating Counrty population Element 
    let Counrty_population_Element = document.createElement("p");
    Counrty_population_Element.textContent = population;
    Counrty_population_Element.classList.add("country-population");
    details_container.appendChild(Counrty_population_Element);



}

function display_results() {
    resultCountries_Element.textContent = "";
    spinner_Element.classList.toggle("d-none");
    for (let country of countriesList) {
        let country_Name = country.name;

        if (country_Name.toLowerCase().includes(search_user_input.toLowerCase())) {
            console.log(country_Name);
            create_Append_country_search_results(country);
        }
    }
}


function Get_countries() {

    spinner_Element.classList.toggle("d-none");

    let url = "https://apis.ccbp.in/countries-data";
    let options = {
        method: "GET",

    };
    fetch(url, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(jsonData) {
            countriesList = jsonData;
            display_results();


        });

}

function onChangeSearchInput(event) {
    search_user_input = event.target.value;
    Get_countries();
}



Get_countries();
searchInput_Element.addEventListener("keyup", onChangeSearchInput);